import React, { useRef, useState, useEffect } from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import SalesActive from "../../svg/SalesActive";
import Sales from "../../svg/Sales";
import QuoteActive from "../../svg/QuoteActive";
import Quote from "../../svg/Quote";
import ProfitabilityActive from "../../svg/ProfitabilityActive";
import Profitability from "../../svg/Profitability";
import ManagementActive from "../../svg/ManagementActive";
import Management from "../../svg/Management";
import Reporting from "../../svg/Reporting";
import ReportingActive from "../../svg/ReportingActive";
import Communication from "../../svg/Communication";
import CommunicationActive from "../../svg/CommunicationActive";
import Calculation from "../../svg/Calculation";
import CalculationActive from "../../svg/CalculationActive";
import Scheduling from "../../svg/Scheduling";
import SchedulingActive from "../../svg/SchedulingActive";
import Employees from "../../svg/Employees";
import EmployeesActive from "../../svg/EmployeesActive";
import { LazyLoadImage } from 'react-lazy-load-image-component';
import DarkMemateBlackBut from "@/layout/hover-button/DarkMemateBlackBut";
const SalesImage = "https://memate-website.s3.ap-southeast-2.amazonaws.com/assets/slider/img-sales-banner-min.png";
const CalculationImage = "https://memate-website.s3.ap-southeast-2.amazonaws.com/assets/slider/img-calculation-min.png";
const EmployeesImage = "https://memate-website.s3.ap-southeast-2.amazonaws.com/assets/slider/img-employees-min.png";
const SchedulingImage = "https://memate-website.s3.ap-southeast-2.amazonaws.com/assets/slider/img-scheduling-min.png";
const CommunicationImage = "https://memate-website.s3.ap-southeast-2.amazonaws.com/assets/slider/img-communication-min.png";
const ReportingImage = "https://memate-website.s3.ap-southeast-2.amazonaws.com/assets/slider/img-reporting-min.png";
const InvoicingImage = "https://memate-website.s3.ap-southeast-2.amazonaws.com/assets/slider/img-Quote-invoice-min.png";
const ProfitabilityImage = "https://memate-website.s3.ap-southeast-2.amazonaws.com/assets/slider/img-profitability-min.png";
const ManagementImage = "https://memate-website.s3.ap-southeast-2.amazonaws.com/assets/slider/img-management-min.png";

const tabs = [
    { 
       label: "Sales",
       image: SalesImage, 
      iconIamgeActive: <SalesActive alt="Sales active icon" />, 
      iconIamge: <Sales alt="Sales icon" />, 
      head: 'Sales', 
      para: 'Manage every step of the sales process—quotes, proposals, follow-ups, and approvals—through a simple, efficient pipeline', 
      link: '/features/sales-management-tools' 
    },
    { 
      label: "Invoicing", 
      image: InvoicingImage, 
      iconIamgeActive: <QuoteActive alt="Quote active icon" />, 
      iconIamge: <Quote alt="Quote icon" />, 
      head: 'Quotes, Invoices & Expenses', 
      para: 'Create professional quotes, convert them into invoices, track expenses, and stay on top of cash flow with ease.', 
      link: '/features/invoicing-software' 
    },
    { 
      label: "Profitability", 
         image: ProfitabilityImage,
      iconIamgeActive: <ProfitabilityActive alt="Profitability active icon" />, 
      iconIamge: <Profitability alt="Profitability icon" />, 
      head: 'Profitability', 
      para: 'Budgeting, real-time operational profit tracking for each project, and expense management, even for long-term projects, make this an indispensable tool.', 
      link: '/features/profitability-and-budgeting-software' 
    },
    { 
      label: "Management", 
      image: ManagementImage,
      iconIamgeActive: <ManagementActive alt="Management active icon" />, 
      iconIamge: <Management alt="Management icon" />, 
      head: 'Project & Job Management', 
      para: 'Track every job from start to finish. Assign tasks, monitor progress, manage timelines, and keep teams aligned in one central workspace.', 
      link: '/features/task-management-software' 
    },
    { 
      label: "Reporting", 
      image: ReportingImage,
      iconIamgeActive: <ReportingActive alt="Reporting active icon" />, 
      iconIamge: <Reporting alt="Reporting icon" />, 
      head: 'Reporting & Business Insights', 
      para: 'Access real-time reports on performance, revenue, costs, and profitability to guide smarter business decisions.', 
      link: '/features/business-reporting-tools' 
    },
    { 
      label: "Communication", 
       image: CommunicationImage,
      iconIamgeActive: <CommunicationActive alt="Communication active icon" />, 
      iconIamge: <Communication alt="Communication icon" />, 
      head: 'CRM & Client Management', 
      para: 'Store customer details, manage leads, track communications, and maintain long-term client relationships without switching systems.', 
      link: '/features/team-communication-tools' 
    },
    { 
      label: "Calculation", 
      image: CalculationImage,
      iconIamgeActive: <CalculationActive alt="Calculation active icon" />, 
      iconIamge: <Calculation alt="Calculation icon" />, 
      head: 'Calculation', 
      para: 'Create instant, accurate quotes and budgets with pre-configured products and services', 
      link: '/features/business-quote-calculator' 
    },
    { 
      label: "Scheduling", 
      image: SchedulingImage,
      iconIamgeActive: <SchedulingActive alt="Scheduling active icon" />, 
      iconIamge: <Scheduling alt="Scheduling icon" />, 
      head: 'Team Scheduling & Time Tracking', 
      para: 'Plan workloads, track hours, and manage productivity across teams — whether in the office or on the field.', 
      link: '/features/job-management-software' 
    },
    { 
      label: "Employees", 
      image: EmployeesImage,
      iconIamgeActive: <EmployeesActive alt="Employees active icon" />, 
      iconIamge: <Employees alt="Employees icon" />, 
      head: 'Employees and Contractors', 
      para: 'Time tracking and contractor management, as well as job assignment and communication, are made easier with our mobile application.', 
      link: '/features/employee-management-tools' 
    }
  ];

function  CenterMode() {
  const [nav1, setNav1] = useState(null);
  const [nav2, setNav2] = useState(null);
  const [currentIndex, setCurrentIndex] = useState(0);

  const slider1 = useRef(null);
  const slider2 = useRef(null);
  const wrapRef = useRef(null);
  const isVisibleRef = useRef(false);
  const isScrollingRef = useRef(false);
  const resumeTimerRef = useRef(null);

  useEffect(() => {
    setNav1(slider1.current);
    setNav2(slider2.current);
  }, []);

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return undefined;

    const pause = () => {
      slider1.current?.slickPause?.();
      slider2.current?.slickPause?.();
    };
    const play = () => {
      slider1.current?.slickPlay?.();
      slider2.current?.slickPlay?.();
    };

    const stopScrollTimer = () => {
      if (resumeTimerRef.current) {
        window.clearTimeout(resumeTimerRef.current);
        resumeTimerRef.current = null;
      }
    };

    const onScroll = () => {
      isScrollingRef.current = true;
      pause();
      stopScrollTimer();
      resumeTimerRef.current = window.setTimeout(() => {
        isScrollingRef.current = false;
        if (isVisibleRef.current) play();
      }, 180);
    };

    pause();

    const observer = new IntersectionObserver(
      ([entry]) => {
        isVisibleRef.current = entry.isIntersecting;
        if (!entry.isIntersecting) {
          pause();
          return;
        }
        if (!isScrollingRef.current) play();
      },
      { threshold: 0.15 }
    );

    observer.observe(el);
    window.addEventListener("scroll", onScroll, { passive: true });

    return () => {
      stopScrollTimer();
      window.removeEventListener("scroll", onScroll);
      observer.disconnect();
    };
  }, []);





 const updateSlideFocus = () => {
    const slides = document.querySelectorAll(".slick-slide");
    slides.forEach((slide) => {
      const isHidden = slide.getAttribute("aria-hidden") === "true";
      const focusables = slide.querySelectorAll("a, button, input, select, textarea");
      focusables.forEach((el) => {
        el.setAttribute("tabindex", isHidden ? "-1" : "0");
      });
    });
  };

  useEffect(() => {
    updateSlideFocus();
    const timer = setTimeout(updateSlideFocus, 200); // small delay to wait for DOM update
    return () => clearTimeout(timer);
  }, [currentIndex]);

  const mainSettings = {
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    autoplay: true,
    autoplaySpeed: 4000,
    fade: true,
    asNavFor: nav2,
    beforeChange: (_, next) => setCurrentIndex(next),
    responsive: [
      {
        breakpoint: 768,
        settings: {
          fade: false
        }
      }
    ]
  };

  const navSettings = {
    slidesToShow: 7,
    slidesToScroll: 1,
    asNavFor: nav1,
    dots: false,
    autoplay: true,
    autoplaySpeed: 4000,
    centerMode: true,
    focusOnSelect: true,
    centerPadding: "0px",
    responsive: [
      {
        breakpoint: 1200,
        settings: {
          slidesToShow: 7
        }
      },
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 4
        }
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 3
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 3
        }
      }
    ]
  };

  return (
    <div
      ref={wrapRef}
      className="oneappwrap large-image-container-wrap"
      style={{ padding: "0 0px 0 0" }}
      
    >
      <Slider {...navSettings} ref={slider2} className="sliderTabWrapper" style={{ marginTop: "20px" }}>
        {tabs.map((tab, index) => (
          <div key={index} role="tabpanel" className="boxCenterModew">
            <div className="boxCenterMode">
              <p>
                {index === currentIndex ? tab.iconIamgeActive : tab.iconIamge}
                <span>{tab.label}</span>
              </p>
            </div>
          </div>
        ))}
      </Slider>
      <Slider {...mainSettings} ref={slider1}>
        {tabs.map((tab, index) => (
             <div 
        className="large-image-container"
            role="group"
            aria-roledescription="slide"
            aria-label={`Slide ${index + 1} of ${tabs.length}`}
        key={index}>
          <div key={index}>
             <LazyLoadImage
              alt={tab.label}
              src={tab.image}
              effect="blur" 
              style={{ width: "100%", height: "auto" }}
            />
            <div style={{ padding: "20px", textAlign: "center" }}>
                <div className="how-to-use">
              <p>{tab.head}</p>
              </div>
               <div className="businesses-mode">
              <span>{tab.para}</span>
              </div>
            <DarkMemateBlackBut
              link2={tab.link}
              buttonTextlight="Find more"
              showButton2={true}
            />
            </div>
          </div>
          </div>
        ))}
      </Slider>
    </div>
  );
}
export default CenterMode;
